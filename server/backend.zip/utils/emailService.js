require("dotenv").config();
const nodemailer = require("nodemailer");

// Validate environment variables
if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
  console.error("❌ Missing EMAIL_USER or EMAIL_PASS in .env file");
  process.exit(1);
}

// Create transporter based on environment
const createTransporter = () => {
  // Check if using cPanel email (has EMAIL_HOST)
  if (process.env.EMAIL_HOST) {
    console.log("📧 Using cPanel email configuration");
    return nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: parseInt(process.env.EMAIL_PORT) || 465,
      secure: process.env.EMAIL_SECURE === "true",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
      tls: {
        rejectUnauthorized: false, // Only if having certificate issues
      },
    });
  }
  // Fallback to Gmail (not recommended for production)
  else {
    console.log(
      "📧 Using Gmail configuration (not recommended for production)",
    );
    return nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });
  }
};

const transporter = createTransporter();

// Verify connection
transporter.verify((error, success) => {
  if (error) {
    console.error("❌ Email configuration error:", error.message);
  } else {
    console.log(
      "✅ Email service ready - Using:",
      process.env.EMAIL_HOST || "Gmail",
    );
  }
});

const templates = {
  contactNotification: (data) => ({
    subject: `New Contact Message from ${data.name}`,
    html: `
      <div style="font-family:Arial;padding:20px;max-width:600px;margin:auto">
        <h2 style="background:#0b2a4a;color:white;padding:15px;text-align:center">
          New Contact Form Submission
        </h2>

        <p><strong>Name:</strong> ${data.name}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Phone:</strong> ${data.phone || "Not provided"}</p>
        <p><strong>Message:</strong> ${data.message}</p>

        <hr/>

        <p style="font-size:12px;color:#666;text-align:center">
          Baishdhara Dental Clinic<br/>
          📞 ${process.env.CLINIC_PHONE || "N/A"}
        </p>
      </div>
    `,
  }),

  appointmentNotification: (data) => ({
    subject: `New Appointment Request - ${data.service}`,
    html: `
      <div style="font-family:Arial;padding:20px;max-width:600px;margin:auto">
        <h2 style="background:#0b2a4a;color:white;padding:15px;text-align:center">
          New Appointment Request
        </h2>

        <p><strong>Patient:</strong> ${data.fullname}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Phone:</strong> ${data.phone}</p>
        <p><strong>Service:</strong> ${data.service}</p>
        <p><strong>Date:</strong> ${new Date(data.date).toLocaleDateString()}</p>
        <p><strong>Time:</strong> ${data.time}</p>

        ${data.notes ? `<p><strong>Notes:</strong> ${data.notes}</p>` : ""}

        <hr/>

        <p><strong>Action Required:</strong> Contact patient to confirm.</p>

        <p style="font-size:12px;color:#666;text-align:center">
          Baishdhara Dental Clinic<br/>
          📞 ${process.env.CLINIC_PHONE || "N/A"}
        </p>
      </div>
    `,
  }),

  autoReply: (data, type) => ({
    subject:
      type === "contact"
        ? "We received your message - Baishdhara Dental"
        : "Appointment request received - Baishdhara Dental",

    html: `
      <div style="font-family:Arial;padding:20px;max-width:600px;margin:auto">
        <h2 style="background:#0b2a4a;color:white;padding:15px;text-align:center">
          Thank You
        </h2>

        <p>Dear ${data.fullname || data.name || "User"},</p>

        <p>
          We have received your ${type === "contact" ? "message" : "appointment request"}.
        </p>

        <p>
          Our team will respond within 24 hours.
        </p>

        <p>
          For urgent help: 📞 ${process.env.CLINIC_PHONE || "N/A"}
        </p>

        <hr/>

        <p style="font-size:12px;color:#666;text-align:center">
          Baishdhara Dental Clinic Team
        </p>
      </div>
    `,
  }),
};

const sendEmail = async (to, subject, html) => {
  try {
    if (!to || !subject || !html) {
      throw new Error("Missing email parameters");
    }

    // Don't send real emails in development unless it's a test recipient
    if (process.env.NODE_ENV === "development") {
      console.log("🔧 DEV MODE - Email would be sent:");
      console.log("To:", to);
      console.log("Subject:", subject);
      console.log(
        "From:",
        `"Baishdhara Dental Clinic" <${process.env.EMAIL_USER}>`,
      );

      // Only send if to includes test recipient or force send flag
      if (!to.includes("test") && !process.env.FORCE_REAL_EMAIL) {
        console.log(
          "⚠️ Email blocked in dev mode. Add FORCE_REAL_EMAIL=true to send anyway",
        );
        return { messageId: "dev-mode-blocked", devMode: true };
      }
    }

    const info = await transporter.sendMail({
      from: `"Baishdhara Dental Clinic" <${process.env.EMAIL_USER}>`,
      to,
      subject,
      html,
    });

    console.log("✅ Email sent:", info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error("❌ Email send failed:", error.message);
    return { success: false, error: error.message };
  }
};

module.exports = {
  sendEmail,
  templates,
};
